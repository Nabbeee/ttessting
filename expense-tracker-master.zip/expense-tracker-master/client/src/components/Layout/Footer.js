import React from "react";

export default () => {
  return (
    <div className="row m-t-50">
      <div className="col-md-12">
        <div className="copyright">
          <p>
            Created By Nitin Patel. Copyright &copy; {new Date().getFullYear()}.
          </p>
        </div>
      </div>
    </div>
  );
};
